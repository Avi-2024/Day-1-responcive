import React from 'react';
import Link from 'next/link';
import  './Navbar.css';

const Navbar = () => {
  return (
    <div className= "container">
      <div
        className= "background"
        style={{ backgroundImage: 'url("/Untitled design.png")' }}
      >
        <div className= "flexContainer">
          <Link href="/">
            <img src="/Logo.png" alt="" className= "logo" />
          </Link>
          <div className= "navbar">
            <Link href="/home" className= "link">
              Home
            </Link>
            <Link href="/services" className= "link">
              Our Services
            </Link>
            <Link href="/find-doctors" className= "link">
              Find Doctor
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;